Talisman Texture Pack
======================
Contains 3 reworked talisman item textures (16x16):
- talisman_skitalets.png  (Скиталец — серый/костяной скелет)
- talisman_gladiator.png  (Гладиатор — бронза/тёмно-красный)
- talisman_pogibel.png    (Погибель — насыщенный красный/чёрный)

Files are placed at:
assets/minecraft/textures/item/

NOTE: These textures are not yet wired to any item via CustomModelData/
item model predicates, because that depends on how your plugin (the one
that defines "talisman_crusher", "talisman_tyrant" etc.) maps items to
model files. To make them actually show up in-game instead of the
original textures, add matching item model JSONs under
assets/minecraft/models/item/ (or your plugin's custom model json)
pointing to these texture paths, using the same CustomModelData values
the plugin already uses for its other talismans.
