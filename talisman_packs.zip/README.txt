Talisman Texture Pack
=====================
Базовый предмет: totem_of_undying
CustomModelData: {"cat": 1001, "gladiator": 1002, "skitalets": 1003, "pogibel": 1004}

Как работает: assets/minecraft/models/item/totem_of_undying.json содержит overrides,
которые по custom_model_data выбирают модели talisman_<имя>.json,
а те ссылаются на текстуры в assets/minecraft/textures/item/.

Если плагин использует другой базовый предмет или другие номера:
1) переименуйте totem_of_undying.json под нужный предмет (и поправьте layer0 на его ванильную текстуру);
2) измените числа в predicate.custom_model_data.
