Talisman Texture Pack (Minecraft 1.21.4, pack_format 46)
Базовый предмет: totem_of_undying
CustomModelData (floats[0]): {"cat": 1001, "gladiator": 1002, "skitalets": 1003, "pogibel": 1004}

assets/minecraft/items/totem_of_undying.json выбирает модель по custom_model_data,
модели лежат в assets/minecraft/models/item/talisman_<имя>.json,
текстуры - в assets/minecraft/textures/item/.

Другой предмет/номера: переименуйте items/totem_of_undying.json, замените fallback-модель и threshold.
